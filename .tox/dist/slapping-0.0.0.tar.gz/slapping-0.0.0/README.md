# slapthatlikebutton-TestingStarterProject
automated testing using tox
